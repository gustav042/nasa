export interface Asteroide {
    nome: string;
    distancia : string;
    tamanho_minimo : string;
    tamanho_maximo : string;
}
