export interface fotoDia{
    titlePhoto : String;
    source : String;
    descricao : String;
}